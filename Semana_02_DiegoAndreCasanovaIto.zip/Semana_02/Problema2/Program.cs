﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problema2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Computadora pc = new Computadora(101, "Lenovo", "Azul", 1200);

            Console.WriteLine("Datos de la computadora (antes):");
            pc.MensajeFinal();

            pc.precioDolares *= 0.38;

            Console.WriteLine("\nDatos de la computadora (después):");
            pc.MensajeFinal();
        }
    }
}
