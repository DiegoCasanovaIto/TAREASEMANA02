﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problema2
{
    public class Computadora
    {
        public int codigo { get; set; }
        public string marca { get; set; }
        public string color { get; set; }
        public double precioDolares { get; set; }

        public Computadora(int codigo, string marca, string color, double precioDolares)
        {
            this.codigo = codigo;
            this.marca = marca;
            this.color = color;
            this.precioDolares = precioDolares;
        }

        public double PrecioEnSoles()
        {
            return precioDolares * 3.78;
        }

        public double PrecioEnEuros()
        {
            return precioDolares / 0.90;
        }

        public void MensajeFinal()
        {
            Console.WriteLine($"Codigo: {codigo}");
            Console.WriteLine($"Marca: {marca}");
            Console.WriteLine($"Color: {color}");
            Console.WriteLine($"Precio en Dólares: {precioDolares:0.00}");
            Console.WriteLine($"Precio en Soles: {PrecioEnSoles():0.00}");
            Console.WriteLine($"Precio en Euros: {PrecioEnEuros():0.00}");
        }
    }
}

