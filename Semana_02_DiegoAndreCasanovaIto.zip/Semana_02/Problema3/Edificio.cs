﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problema3
{
    internal class Edificio
    {
        public int codigo { get; set; }
        public int n_Departamentos { get; set; }
        public int cantidadPisos { get; set; }
        public double pre_depart_dolares { get; set; }

        public Edificio(int codigo, int n_Departamentos, int cantidadPisos, double pre_depart_dolares)
        {
            this.codigo = codigo;
            this.n_Departamentos = n_Departamentos;
            this.cantidadPisos = cantidadPisos;
            this.pre_depart_dolares = pre_depart_dolares;

        }

        public double PrecioTotalEdificio()
        {
            return n_Departamentos * pre_depart_dolares;
        }

        public void MensajeFinal()
        {
            Console.WriteLine($"Código: {codigo}");
            Console.WriteLine($"Número de Departamentos: {n_Departamentos}");
            Console.WriteLine($"Cantidad de Pisos: {cantidadPisos}");
            Console.WriteLine($"Precio de un Departamento (USD): {pre_depart_dolares:0.00}");
            Console.WriteLine($"Precio Total del Edificio (USD): {PrecioTotalEdificio():0.00}");
        }
    }
}


