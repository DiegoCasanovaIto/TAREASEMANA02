﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problema3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Ingrese el código del edificio: ");
            int codigo = int.Parse(Console.ReadLine());

            Console.Write("Ingrese el número de departamentos: ");
            int n_departamentos = int.Parse(Console.ReadLine());

            Console.Write("Ingrese la cantidad de pisos: ");
            int cantidadPisos = int.Parse(Console.ReadLine());

            Console.Write("Ingrese el precio de un departamento en dólares: ");
            double pre_depart_dolares = double.Parse(Console.ReadLine());

           
            Edificio edificio = new Edificio(codigo, n_departamentos, cantidadPisos, pre_depart_dolares);

           
            Console.WriteLine($"Datos del edificio (antes de incrementar el precio del departamento):");
            edificio.MensajeFinal();

            edificio.pre_depart_dolares *= 1.20;

            Console.WriteLine("\nDatos del edificio (después de incrementar el precio del departamento):");
            edificio.MensajeFinal();
        }
    }
}
