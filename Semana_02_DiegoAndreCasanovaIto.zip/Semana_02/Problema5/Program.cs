﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problema5
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Video v = new Video(101, "Chibolin y su Arrresto XD", 10.00, 400, 3.78);

            Console.WriteLine($"Datos del video (antes): ");
            v.MensajeFinal();

            v.precioSoles += 5.50;

            Console.WriteLine("\nDatos del video (despues): ");
            v.MensajeFinal();
        }
    }
}
