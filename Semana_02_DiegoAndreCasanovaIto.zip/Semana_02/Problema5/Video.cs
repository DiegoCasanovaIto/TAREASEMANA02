﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problema5
{
    public class Video
    {

        public  int codigo { get; set; }
        public string nombreVideo { get; set; }
        public double duracion { get; set; }
        public double precioSoles { get; set; }
        public double tipoCambio { get; set; }

        public Video(int codigo, string nombreVideo, double duracion, double precioSoles, double tipoCambio)
        {
            this.codigo = codigo;
            this.nombreVideo = nombreVideo;
            this.duracion = duracion;
            this.precioSoles = precioSoles;
            this.tipoCambio = tipoCambio;
        }

        public double CalcularPrecioDelVideo()
        {
            return precioSoles / tipoCambio;
        }

        public void MensajeFinal()
        {
            Console.WriteLine($"Codigo: {codigo}");
            Console.WriteLine($"Nombre del video: {nombreVideo}");
            Console.WriteLine($"Duracion: {duracion:00:}00");
            Console.WriteLine($"Precio en Soles: {precioSoles: 0.00}");
            Console.WriteLine($"Tipo de Cambio: {tipoCambio}");
            Console.WriteLine($"Precio del Video: {CalcularPrecioDelVideo():0.00}");
        }
        }
    }

