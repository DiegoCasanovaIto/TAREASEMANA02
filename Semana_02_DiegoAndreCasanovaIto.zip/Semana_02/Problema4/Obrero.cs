﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problema4
{
    public class Obrero
    {

        public int codigo { get; set; }
        public string nombre { get; set; }
        public int horasTrabajadas { get; set; }
        public double tarifaXhora { get; set; }

        public Obrero(int codigo, string nombre, int horasTrabajadas, double tarifaXhora)
        {
            this.codigo = codigo;
            this.nombre = nombre;
            this.horasTrabajadas = horasTrabajadas;
            this.tarifaXhora = tarifaXhora;
        }

        public double CalcularSueldoBruto()
        {
            return horasTrabajadas * tarifaXhora;
        }

        public double CalcularDescuentoAFP()
        {
            return CalcularSueldoBruto() * 0.10;
        }

        public double CalcularDescuentoEPS()
        {
            return CalcularSueldoBruto() * 0.05;
        }

        public double CalcularSueldoNeto()
        {
            return CalcularSueldoBruto() - CalcularDescuentoAFP() - CalcularDescuentoEPS();
        }

        public void MensajeFinal()
        {
            Console.WriteLine($"Código: {codigo}");
            Console.WriteLine($"Nombre: {nombre}");
            Console.WriteLine($"Horas trabajadas: {horasTrabajadas}");
            Console.WriteLine($"Tarifa por hora: {tarifaXhora:0.00}");
            Console.WriteLine($"Sueldo bruto: {CalcularSueldoBruto():0.00}");
            Console.WriteLine($"Descuento AFP (10%): {CalcularDescuentoAFP():0.00}");
            Console.WriteLine($"Descuento EPS (5%): {CalcularDescuentoEPS():0.00}");
            Console.WriteLine($"Sueldo neto: {CalcularSueldoNeto():0.00}");
        }
    }
}
