﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problema4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Obrero obrero = new Obrero(101, "Diego Casanova", 48, 6.25);

            Console.WriteLine("Datos del obrero (antes):");
            obrero.MensajeFinal();

            // Aumentar en 8 las horas trabajadas y disminuir la tarifa por hora en 1.5%
            obrero.horasTrabajadas += 8;
            obrero.tarifaXhora *= 0.985;  // Descuento del 1.5%

            Console.WriteLine("\nDatos del obrero (después):");
            obrero.MensajeFinal();
        }
    }
}
