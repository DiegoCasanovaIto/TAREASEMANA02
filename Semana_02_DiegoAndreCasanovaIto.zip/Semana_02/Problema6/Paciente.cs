﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problema6
{
    public class Paciente
    {
        public string nombre { get; set; }
        public string apellido { get; set; }
        public int edad { get; set; }
        public double talla { get; set; }
        public double peso { get; set; }

        public Paciente(string nombre, string apellido, int edad, double talla, double peso)
        {
            this.nombre = nombre;
            this.apellido = apellido;
            this.edad = edad;
            this.talla = talla;
            this.peso = peso;
        }

       public string DeterminarEdad()
        {
            return edad >= 18 ? "Mayor de edad" : "Menor de edad";
        }

        public void MensajeFinal()
        {
            Console.WriteLine($"Nombre: {nombre}");
            Console.WriteLine($"Apellido: {apellido}");
            Console.WriteLine($"Edad: {edad} ({DeterminarEdad()})");
            Console.WriteLine($"Talla: {talla:0.00} m");
            Console.WriteLine($"Peso: {peso:0.00} kg");
        }
    }
}
