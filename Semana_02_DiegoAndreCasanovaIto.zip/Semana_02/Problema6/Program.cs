﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problema6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Paciente pa = new Paciente("Jose", "Hermoza", 17, 1.72, 70);

            Console.WriteLine("Datos de paciente (antes): ");
            pa.MensajeFinal();

            //Modificamos la edad del paciente :D
            pa.edad = 21;

            Console.WriteLine("\nDatos del paciente (despues): ");
            pa.MensajeFinal();
        }
    }
}
