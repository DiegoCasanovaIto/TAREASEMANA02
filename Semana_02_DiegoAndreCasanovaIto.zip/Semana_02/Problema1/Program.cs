﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problema1
{
    internal class Program
    {
        //metodo principal que ya viene por predeterminado, lo bueno XD
        static void Main(string[] args)
        {

            //Inicio de un objeto de tipo Consola con datos fijos :D
            Celular c = new Celular(123456789, "Juan Perez", 360, 0.50);

            //Y este es el llamado del metodo listado de la clase anterior.
            Console.WriteLine("Datos del celular (antes):");
            c.MensajeFinal();

            //Unos cuantos calculos :D
            c.segundosConsumidos += 20;
            c.precioXsegundo *= 0.5;

            //y otro metodo listado para concluir el cambio que le dimos.
            Console.WriteLine("\nDatos del celular (después):");
            c.MensajeFinal();
        }
    }
}
