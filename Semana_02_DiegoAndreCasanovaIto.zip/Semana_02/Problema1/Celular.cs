﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problema1
{
    public class Celular
    {
        //Atributos con metodos get y set
        public int numero { get; set; }
        public string usuario { get; set; }
        public int segundosConsumidos { get; set; }
        public double precioXsegundo { get; set; }

        //El constructor para iniciar los atributos
        public Celular(int numero, string usuario, int segundosConsumidos, double precioPorSegundo)
        {
            this.numero = numero;
            this.usuario = usuario;
            this.segundosConsumidos = segundosConsumidos;
            this.precioXsegundo = precioPorSegundo;
        }

        //Otra forma de hacer metodos get y set; pero me quedo con la otra mas rapido y eficiente; ademas de gastar menos datos y tiempo, osea su metodo es lo mejor que he visto en el instituto.

        //public int Codigo
        //{
          //  get { return codigo; } 
          //  set { codigo = value; }
        //}

        //Metodos de retorno, GAAAAAAAA vas a caer peluchin
        public double CalcularCostoPorConsumo()
        {
            return segundosConsumidos * precioXsegundo;
        }

        public double CalcularImpuestoIGV()
        {
            return CalcularCostoPorConsumo() * 0.18;
        }

        public double CalcularTotalPagar()
        {
            return CalcularCostoPorConsumo() + CalcularImpuestoIGV();
        }

        //Metodo de listar, se usa o usamos mayormente para adjuntar en mensajes los datos completos de la clase.
        //YO le pongo MensajeFinal por costumbre y orden jeje.
        public void MensajeFinal()
        {
            Console.WriteLine($"Número: {numero}");
            Console.WriteLine($"Usuario: {usuario}");
            Console.WriteLine($"Segundos Consumidos: {segundosConsumidos}");
            Console.WriteLine($"Precio por Segundo: {precioXsegundo}");
            Console.WriteLine($"Costo por Consumo: {CalcularCostoPorConsumo():0.00}");
            Console.WriteLine($"Impuesto IGV (18%): {CalcularImpuestoIGV():0.00}");
            Console.WriteLine($"Total a Pagar: {CalcularTotalPagar():0.00}");
        }
    }
}
