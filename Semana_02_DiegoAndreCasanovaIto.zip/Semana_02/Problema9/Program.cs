﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problema9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Pelota pe = new Pelota("Adidas", 450, 12.6, 21.5, 120);

            Console.WriteLine("Datos de la Pelota (antes): ");
            pe.MensajeFinal();

            pe.precio *= 0.25;
            pe.diametro_cm += 1;

            Console.WriteLine("Datos de la pelota(despues): ");
            pe.MensajeFinal();
        }
    }
}
