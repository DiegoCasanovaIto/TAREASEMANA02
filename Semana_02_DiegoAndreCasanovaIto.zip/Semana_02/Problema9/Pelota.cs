﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problema9
{
    public class Pelota
    {
        public string marca { get; set; }
        public double pesoGramos { get; set; }
        public double presionLibras { get; set; }
        public double diametro_cm { get; set; }
        public double precio { get; set; }

        public Pelota(string marca, double pesoGramos, double presionLibras, double diametro_cm, double precio)
        {
            this.marca = marca;
            this.pesoGramos = pesoGramos;
            this.presionLibras = presionLibras;
            this.diametro_cm = diametro_cm;
            this.precio = precio;
        }

        public double CalcularRadio()
        {
            return diametro_cm / 2;
        }

        public double CalcularVolumenBalon()
        {
            return 4 * 3.1416 * CalcularRadio() * CalcularRadio() * CalcularRadio() / 3;
        }

        public double CalcularDescuento()
        {
            return precio * 0.10;
        }

        public double CalcularImportePagar()
        {
            return precio - CalcularDescuento();
        }

        public void MensajeFinal()
        {
            Console.WriteLine($"Marca: {marca}");
            Console.WriteLine($"Peso en Gramos: {pesoGramos:0.00}gr");
            Console.WriteLine($"Presion el libras: {presionLibras:0.00}lb");
            Console.WriteLine($"Diametro en Centrimetros: {diametro_cm:0.00}cm");
            Console.WriteLine($"Precio: {precio:0.00}");
            Console.WriteLine($"Radio: {CalcularRadio():0.00}cm");
            Console.WriteLine($"Volumen del Balon: {CalcularVolumenBalon():0.00}cm°3");
            Console.WriteLine($"Descuento: {CalcularDescuento():0.00}");
            Console.WriteLine($"Importe a Pagar: {CalcularImportePagar():0.00}");
        }
    }

}

