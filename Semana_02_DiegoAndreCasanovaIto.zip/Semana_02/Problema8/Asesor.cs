﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problema8
{
    public class Asesor
    {
        public int codigo { get; set; }
        public string nombre { get; set; }
        public int horasTrabajadas { get; set; }
        public double tarifaXhora { get; set; }

        public Asesor(int codigo, string nombre, int horasTrabajadas, double tarifaXhora)
        {
            this.codigo = codigo;
            this.nombre = nombre;
            this.horasTrabajadas = horasTrabajadas;
            this.tarifaXhora = tarifaXhora;
        }
        public double CalcularSueldoBruto()
        {
            return horasTrabajadas * tarifaXhora;
        }

        public double CalcularDescuento()
        {
            return  CalcularSueldoBruto()*0.15 ;
        }
        public double CalculadoraSueldoNeto()
        {
            return CalcularSueldoBruto() - CalcularDescuento();
        }

        public void MensajeFinal()
        {
            Console.WriteLine($"Codigo: {codigo}");
            Console.WriteLine($"Nombre: {nombre}");
            Console.WriteLine($"Horas Trabajadas: {horasTrabajadas:0.00}");
            Console.WriteLine($"Tarifa por Hora: {tarifaXhora:0.00}");
            Console.WriteLine($"Sueldo Bruto: {CalcularSueldoBruto():0.00}");
            Console.WriteLine($"Descuento: {CalcularDescuento():0.00}");
            Console.WriteLine($"Sueldo Neto: {CalculadoraSueldoNeto():0.00}");

        }
    }
}

