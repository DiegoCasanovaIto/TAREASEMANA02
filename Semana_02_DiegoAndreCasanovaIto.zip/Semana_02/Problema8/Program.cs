﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problema8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Ingrese el codigo del asesor: ");
            int codigo = int.Parse(Console.ReadLine());

            Console.Write("Ingrese el nombre del asesor: ");
            string nombre = Console.ReadLine();

            Console.Write("Ingrese las horas trabajadas: ");
            int horasTrabajadas = int.Parse(Console.ReadLine());

            Console.Write("Ingrese la tarifa por hora: ");
            double tarifaXhora = double.Parse(Console.ReadLine());

            Asesor ase = new Asesor(codigo,nombre,horasTrabajadas, tarifaXhora);

            Console.WriteLine("\nDatos del Asesor (antes): ");
            ase.MensajeFinal();

            ase.horasTrabajadas += 10;
            ase.tarifaXhora *= 0.85;

            Console.WriteLine("\nDatos del Asesor (despues): ");
            ase.MensajeFinal();
        }
    }
}
