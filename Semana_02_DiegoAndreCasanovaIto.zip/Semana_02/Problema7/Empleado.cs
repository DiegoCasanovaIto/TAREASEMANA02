﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problema7
{
    public class Empleado
    {
        public int codigo { get; set; }
        public string nombre { get; set; }
        public int numeroCelular { get; set; }
        public double sueldoSoles { get; set; }

        public Empleado(int codigo, string nombre, int numeroCelular, double sueldoSoles)
        {
            this.codigo = codigo;
            this.nombre = nombre;
            this.numeroCelular = numeroCelular;
            this.sueldoSoles = sueldoSoles;
        }

        public string VerificarSueldo()
        {
            if (sueldoSoles > 3500)
            {
                return "mayor a 3500";
            }
            else if (sueldoSoles < 3500)
            {
                return "menor a 3500";
            }
            else
            {
                return "igual a 3500";
            }
        }

        public void MensajeFinal()
        {
            Console.WriteLine($"Codigo: {codigo}");
            Console.WriteLine($"Nombre: {nombre}");
            Console.WriteLine($"Número de Celular: {numeroCelular}");
            Console.WriteLine($"Sueldo: {sueldoSoles:0.00} soles");
            Console.WriteLine($"El sueldo es {VerificarSueldo()}.");
        }
    }
}
