﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problema7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Ingrese el codigo del empleado: ");
            int codigo = int.Parse(Console.ReadLine());

            Console.Write("Ingrese el nombre del empleado: ");
            string nombre = Console.ReadLine();

            Console.Write("Ingrese el número de celular: ");
            int numeroCelular = int.Parse(Console.ReadLine());

            Console.Write("Ingrese el sueldo en soles: ");
            double sueldoSoles = double.Parse(Console.ReadLine());

            Empleado emp = new Empleado(codigo, nombre, numeroCelular, sueldoSoles);

            Console.WriteLine("\nDatos del empleado (antes): ");
            emp.MensajeFinal();

            emp.numeroCelular = 950867915;
            emp.sueldoSoles += 200;

            Console.WriteLine("\nDatos del empleado (despues): ");
            emp.MensajeFinal();
        }
    }
}
