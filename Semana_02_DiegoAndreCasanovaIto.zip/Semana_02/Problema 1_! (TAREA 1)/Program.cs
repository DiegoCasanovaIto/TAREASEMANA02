﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problema_1____TAREA_1_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Docente doc = new Docente(101, "Diego", 70, 30);

            Console.WriteLine("Datos del Docente: ");
            doc.MensajeFinal();
        }
    }
}
