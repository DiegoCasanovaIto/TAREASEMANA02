﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Problema_1____TAREA_1_
{
    public class Docente
    {
        public int codigo { get; set; }
        public string nombre { get; set; }
        public int horasTrabajadas { get; set; }
        public double tarifaHoraria { get; set; }

        public Docente(int codigo, string nombre, int horasTrabajadas, double tarifaHoraria)
        {
            this.codigo = codigo;
            this.nombre = nombre;
            this.horasTrabajadas = horasTrabajadas;
            this.tarifaHoraria = tarifaHoraria;
        }

        public double CalcularSueldoBruto()
        {
            return horasTrabajadas * tarifaHoraria;
        }


        public double CalcularDescuento()
        {
            if (CalcularSueldoBruto() < 4500)
            {
                return CalcularSueldoBruto() * 0.12;
            }
            else if (CalcularSueldoBruto() >= 4500)
            {
                return CalcularSueldoBruto() * 0.14;
            }
            else if (CalcularSueldoBruto() < 6500)
            {
                return CalcularSueldoBruto() * 0.14;
            }
            else
            {
                return CalcularSueldoBruto() * 0.16;
            }
        }

        public double CalcularSueldoNeto()
        {
            return CalcularSueldoBruto() - CalcularDescuento();
        }
        public void MensajeFinal()
        {
            Console.WriteLine($"Codigo: {codigo}");
            Console.WriteLine($"Nombre: {nombre}");
            Console.WriteLine($"Horas Trabajadas: {horasTrabajadas}");
            Console.WriteLine($"Tarifa Horaria: {tarifaHoraria:0.00}");
            Console.WriteLine($"Sueldo Bruto: {CalcularSueldoBruto():0.00}");
            Console.WriteLine($"Descuento: {CalcularDescuento():0.00}");
            Console.WriteLine($"Sueldo Neto: {CalcularSueldoNeto():0.00}");
        }
    }
}
